package plotme

class UploadedFile {

	String filePath
	String fileName
	
	
//    static constraints = {
//    }
}

ant.mkdir dir:"${basedir}/grails-app/assets"

ant.mkdir dir:"${basedir}/grails-app/assets/javascripts"

ant.mkdir dir: 	"${basedir}/grails-app/assets/stylesheets"

ant.mkdir dir: "${basedir}/grails-app/assets/images"

// TODO: Create Templated stylesheet and javascript file

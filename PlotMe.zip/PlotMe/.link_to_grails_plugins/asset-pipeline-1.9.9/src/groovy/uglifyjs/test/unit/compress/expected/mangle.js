(function(){var a=function b(a,b,c){return b}})()

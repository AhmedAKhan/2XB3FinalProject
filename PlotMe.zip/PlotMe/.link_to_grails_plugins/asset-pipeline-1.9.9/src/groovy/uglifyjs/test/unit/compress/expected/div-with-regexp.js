print(a/ /[a-z]/)

var a = {};
a["this"] = 1;
a["that"] = 2;
label1 : {
    label2 : {
        break label2;
        console.log(2);
    }
    console.log(1);
}
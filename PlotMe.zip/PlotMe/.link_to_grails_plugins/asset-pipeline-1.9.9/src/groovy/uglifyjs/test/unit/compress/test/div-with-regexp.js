print(a / /[a-z]/);

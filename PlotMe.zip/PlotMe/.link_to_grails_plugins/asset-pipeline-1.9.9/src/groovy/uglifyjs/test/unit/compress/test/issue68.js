function f() {
        if (a) return;
        g();
        function g(){}
};
